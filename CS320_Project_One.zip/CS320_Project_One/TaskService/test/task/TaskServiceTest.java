package task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TaskServiceTest {

    private static final String TASK_ID = "1001";
    private static final String TASK_NAME = "Homework";
    private static final String TASK_DESCRIPTION = "Finish assignment";

    @Test
    void testAddTask_withUniqueId_taskIsStored() {
        TaskService service = new TaskService();

        Task task = new Task(
                TASK_ID,
                TASK_NAME,
                TASK_DESCRIPTION);

        service.addTask(task);

        assertEquals(
                task,
                service.getTask(TASK_ID));
    }

    @Test
    void testAddTask_withDuplicateId_throwsException() {
        TaskService service = new TaskService();

        Task firstTask = new Task(
                TASK_ID,
                TASK_NAME,
                TASK_DESCRIPTION);

        Task duplicateTask = new Task(
                TASK_ID,
                "Grocery",
                "Buy milk");

        service.addTask(firstTask);

        assertThrows(
                IllegalArgumentException.class,
                () -> service.addTask(duplicateTask));
    }

    @Test
    void testDeleteTask_withExistingId_taskIsRemoved() {
        TaskService service = new TaskService();

        Task task = new Task(
                TASK_ID,
                TASK_NAME,
                TASK_DESCRIPTION);

        service.addTask(task);
        service.deleteTask(TASK_ID);

        assertNull(service.getTask(TASK_ID));
    }

    @Test
    void testDeleteTask_withMissingId_throwsException() {
        TaskService service = new TaskService();

        assertThrows(
                IllegalArgumentException.class,
                () -> service.deleteTask("9999"));
    }

    @Test
    void testUpdateTask_withValidTask_taskIsUpdated() {
        TaskService service = new TaskService();

        Task task = new Task(
                TASK_ID,
                TASK_NAME,
                TASK_DESCRIPTION);

        Task updatedTask = new Task(
                TASK_ID,
                "Project",
                "Complete Module Four milestone");

        service.addTask(task);
        service.updateTask(TASK_ID, updatedTask);

        assertEquals(
                updatedTask,
                service.getTask(TASK_ID));
    }

    @Test
    void testUpdateTask_withMissingId_throwsException() {
        TaskService service = new TaskService();

        Task updatedTask = new Task(
                "9999",
                "Project",
                "Complete milestone");

        assertThrows(
                IllegalArgumentException.class,
                () -> service.updateTask("9999", updatedTask));
    }

    @Test
    void testGetTask_withMissingId_returnsNull() {
        TaskService service = new TaskService();

        assertNull(service.getTask("9999"));
    }

    @Test
    void testGetTask_withExistingId_returnsEqualNewInstance() {
        TaskService service = new TaskService();

        Task task = new Task(
                TASK_ID,
                TASK_NAME,
                TASK_DESCRIPTION);

        service.addTask(task);

        Task retrievedTask = service.getTask(TASK_ID);

        assertAll(
                () -> assertEquals(task, retrievedTask),
                () -> assertNotSame(task, retrievedTask));
    }
}