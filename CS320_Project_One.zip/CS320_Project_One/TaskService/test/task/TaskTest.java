package task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TaskTest {

    private static final String TASK_ID = "1001";
    private static final String TASK_NAME = "Homework";
    private static final String TASK_DESCRIPTION = "Finish assignment";

    @Test
    void testConstructor_withValidValues_createsTask() {
        Task task = new Task(
                TASK_ID,
                TASK_NAME,
                TASK_DESCRIPTION);

        assertEquals(TASK_ID, task.getTaskId());
    }

    @Test
    void testConstructor_withNullId_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Task(
                        null,
                        TASK_NAME,
                        TASK_DESCRIPTION));
    }

    @Test
    void testConstructor_withIdLongerThanTenCharacters_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Task(
                        "12345678901",
                        TASK_NAME,
                        TASK_DESCRIPTION));
    }

    @Test
    void testConstructor_withNullName_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Task(
                        TASK_ID,
                        null,
                        TASK_DESCRIPTION));
    }

    @Test
    void testConstructor_withNameLongerThanTwentyCharacters_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Task(
                        TASK_ID,
                        "ThisNameIsDefinitelyWayTooLong",
                        TASK_DESCRIPTION));
    }

    @Test
    void testConstructor_withNullDescription_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Task(
                        TASK_ID,
                        TASK_NAME,
                        null));
    }

    @Test
    void testConstructor_withDescriptionLongerThanFiftyCharacters_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Task(
                        TASK_ID,
                        TASK_NAME,
                        "This description is intentionally made much longer than fifty characters to trigger validation."));
    }

    @Test
    void testSetName_withValidName_updatesName() {
        Task task = new Task(
                TASK_ID,
                TASK_NAME,
                TASK_DESCRIPTION);

        task.setName("Project");

        assertEquals("Project", task.getName());
    }

    @Test
    void testSetDescription_withValidDescription_updatesDescription() {
        Task task = new Task(
                TASK_ID,
                TASK_NAME,
                TASK_DESCRIPTION);

        task.setDescription("Complete Module Four milestone.");

        assertEquals(
                "Complete Module Four milestone.",
                task.getDescription());
    }
}