package task;

public class Task {

    private final String taskId;
    private String name;
    private String description;

    public Task(String taskId, String name, String description) {

        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Invalid task ID");
        }

        this.taskId = taskId;

        setName(name);
        setDescription(description);
    }

    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public void setName(String name) {

        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid task name");
        }

        this.name = name;
    }

    public void setDescription(String description) {

        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException(
                    "Invalid task description");
        }

        this.description = description;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }

        if (object == null || getClass() != object.getClass()) {
            return false;
        }

        Task other = (Task) object;

        return taskId.equals(other.taskId)
                && name.equals(other.name)
                && description.equals(other.description);
    }

    @Override
    public int hashCode() {
        int result = taskId.hashCode();
        result = 31 * result + name.hashCode();
        result = 31 * result + description.hashCode();
        return result;
    }
}