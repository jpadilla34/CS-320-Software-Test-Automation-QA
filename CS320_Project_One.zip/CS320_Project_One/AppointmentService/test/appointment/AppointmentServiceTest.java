package appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

class AppointmentServiceTest {

    private static final String VALID_ID = "A1001";
    private static final String VALID_DESCRIPTION = "Routine appointment";
    private static final Date FUTURE_DATE =
            new Date(System.currentTimeMillis() + 86400000L);

    @Test
    void testAddAppointment_withUniqueId_appointmentIsStored() {
        AppointmentService service = new AppointmentService();

        Appointment appointment =
                new Appointment(
                        VALID_ID,
                        FUTURE_DATE,
                        VALID_DESCRIPTION);

        service.addAppointment(appointment);

        assertEquals(
                appointment,
                service.getAppointment(VALID_ID));
    }

    @Test
    void testAddAppointment_withDuplicateId_throwsException() {
        AppointmentService service = new AppointmentService();

        Appointment firstAppointment =
                new Appointment(
                        VALID_ID,
                        FUTURE_DATE,
                        VALID_DESCRIPTION);

        Appointment duplicateAppointment =
                new Appointment(
                        VALID_ID,
                        new Date(System.currentTimeMillis() + 172800000L),
                        "Second appointment");

        service.addAppointment(firstAppointment);

        assertThrows(
                IllegalArgumentException.class,
                () -> service.addAppointment(duplicateAppointment));
    }

    @Test
    void testDeleteAppointment_withExistingId_appointmentIsRemoved() {
        AppointmentService service = new AppointmentService();

        Appointment appointment =
                new Appointment(
                        VALID_ID,
                        FUTURE_DATE,
                        VALID_DESCRIPTION);

        service.addAppointment(appointment);
        service.deleteAppointment(VALID_ID);

        assertNull(service.getAppointment(VALID_ID));
    }

    @Test
    void testDeleteAppointment_withMissingId_throwsException() {
        AppointmentService service = new AppointmentService();

        assertThrows(
                IllegalArgumentException.class,
                () -> service.deleteAppointment("MISSING"));
    }

    @Test
    void testGetAppointment_withMissingId_returnsNull() {
        AppointmentService service = new AppointmentService();

        assertNull(service.getAppointment("MISSING"));
    }

    @Test
    void testGetAppointment_withExistingId_returnsEqualNewInstance() {
        AppointmentService service = new AppointmentService();

        Appointment appointment =
                new Appointment(
                        VALID_ID,
                        FUTURE_DATE,
                        VALID_DESCRIPTION);

        service.addAppointment(appointment);

        Appointment retrievedAppointment =
                service.getAppointment(VALID_ID);

        assertAll(
                () -> assertEquals(
                        appointment,
                        retrievedAppointment),
                () -> assertNotSame(
                        appointment,
                        retrievedAppointment));
    }
}