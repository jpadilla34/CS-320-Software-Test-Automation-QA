package appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

class AppointmentTest {

    private static final String VALID_ID = "A1001";
    private static final String VALID_DESCRIPTION = "Routine appointment";
    private static final Date FUTURE_DATE =
            new Date(System.currentTimeMillis() + 86400000L);

    @Test
    void testConstructor_withValidValues_createsAppointment() {
        Appointment appointment =
                new Appointment(
                        VALID_ID,
                        FUTURE_DATE,
                        VALID_DESCRIPTION);

        assertEquals(VALID_ID, appointment.getAppointmentId());
    }
    @Test
    void testConstructor_withNullId_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        null,
                        FUTURE_DATE,
                        VALID_DESCRIPTION));
    }

    @Test
    void testConstructor_withIdLongerThanTenCharacters_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "12345678901",
                        FUTURE_DATE,
                        VALID_DESCRIPTION));
    }

    @Test
    void testConstructor_withNullDate_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        VALID_ID,
                        null,
                        VALID_DESCRIPTION));
    }

    @Test
    void testConstructor_withPastDate_throwsException() {
        Date pastDate =
                new Date(System.currentTimeMillis() - 86400000L);

        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        VALID_ID,
                        pastDate,
                        VALID_DESCRIPTION));
    }

    @Test
    void testConstructor_withNullDescription_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        VALID_ID,
                        FUTURE_DATE,
                        null));
    }

    @Test
    void testConstructor_withDescriptionLongerThanFiftyCharacters_throwsException() {
        String longDescription =
                "This appointment description is intentionally longer than fifty characters.";

        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        VALID_ID,
                        FUTURE_DATE,
                        longDescription));
    }

    @Test
    void testSetAppointmentDate_withValidFutureDate_updatesDate() {
        Appointment appointment =
                new Appointment(
                        VALID_ID,
                        FUTURE_DATE,
                        VALID_DESCRIPTION);

        Date updatedDate =
                new Date(System.currentTimeMillis() + 172800000L);

        appointment.setAppointmentDate(updatedDate);

        assertEquals(updatedDate, appointment.getAppointmentDate());
    }

    @Test
    void testSetDescription_withValidDescription_updatesDescription() {
        Appointment appointment =
                new Appointment(
                        VALID_ID,
                        FUTURE_DATE,
                        VALID_DESCRIPTION);

        String updatedDescription = "Updated appointment";

        appointment.setDescription(updatedDescription);

        assertEquals(
                updatedDescription,
                appointment.getDescription());
    }
}