package contact;

import java.util.HashMap;
import java.util.Map;

public class ContactService {

    private final Map<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null.");
        }

        String contactId = contact.getContactId();

        if (contacts.containsKey(contactId)) {
            throw new IllegalArgumentException(
                "A contact with this ID already exists."
            );
        }

        contacts.put(contactId, contact);
    }

    public void deleteContact(String contactId) {
        if (contactId == null || !contacts.containsKey(contactId)) {
            throw new IllegalArgumentException(
                "Contact ID was not found."
            );
        }

        contacts.remove(contactId);
    }

    public void updateContact(Contact updatedContact) {
        if (updatedContact == null) {
            throw new IllegalArgumentException(
                "Contact cannot be null."
            );
        }

        Contact existingContact =
                contacts.get(updatedContact.getContactId());

        if (existingContact == null) {
            throw new IllegalArgumentException(
                "Contact ID was not found."
            );
        }

        existingContact.setFirstName(
                updatedContact.getFirstName());

        existingContact.setLastName(
                updatedContact.getLastName());

        existingContact.setPhone(
                updatedContact.getPhone());

        existingContact.setAddress(
                updatedContact.getAddress());
    }

    public Contact getContact(String contactId) {
        Contact contact = contacts.get(contactId);

        if (contact == null) {
            return null;
        }

        return new Contact(
                contact.getContactId(),
                contact.getFirstName(),
                contact.getLastName(),
                contact.getPhone(),
                contact.getAddress());
    }
}