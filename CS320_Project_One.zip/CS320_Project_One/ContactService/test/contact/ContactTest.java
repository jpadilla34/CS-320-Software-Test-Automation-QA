package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactTest {

    private static final String CONTACT_ID = "1001";
    private static final String FIRST_NAME = "Jeremy";
    private static final String LAST_NAME = "Padilla";
    private static final String PHONE = "8605551234";
    private static final String ADDRESS = "123 Main Street";

    @Test
    void testConstructor_withValidValues_createsContact() {
        Contact contact = new Contact(
                CONTACT_ID,
                FIRST_NAME,
                LAST_NAME,
                PHONE,
                ADDRESS);

        assertEquals(CONTACT_ID, contact.getContactId());
    }

    @Test
    void testConstructor_withNullId_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        null,
                        FIRST_NAME,
                        LAST_NAME,
                        PHONE,
                        ADDRESS));
    }

    @Test
    void testConstructor_withIdLongerThanTenCharacters_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        "12345678901",
                        FIRST_NAME,
                        LAST_NAME,
                        PHONE,
                        ADDRESS));
    }

    @Test
    void testConstructor_withNullFirstName_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        CONTACT_ID,
                        null,
                        LAST_NAME,
                        PHONE,
                        ADDRESS));
    }

    @Test
    void testConstructor_withFirstNameLongerThanTenCharacters_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        CONTACT_ID,
                        "Christopher",
                        LAST_NAME,
                        PHONE,
                        ADDRESS));
    }

    @Test
    void testConstructor_withNullLastName_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        CONTACT_ID,
                        FIRST_NAME,
                        null,
                        PHONE,
                        ADDRESS));
    }

    @Test
    void testConstructor_withLastNameLongerThanTenCharacters_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        CONTACT_ID,
                        FIRST_NAME,
                        "Longlastname",
                        PHONE,
                        ADDRESS));
    }

    @Test
    void testConstructor_withNullPhone_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        CONTACT_ID,
                        FIRST_NAME,
                        LAST_NAME,
                        null,
                        ADDRESS));
    }

    @Test
    void testConstructor_withPhoneShorterThanTenDigits_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        CONTACT_ID,
                        FIRST_NAME,
                        LAST_NAME,
                        "860555123",
                        ADDRESS));
    }

    @Test
    void testConstructor_withPhoneLongerThanTenDigits_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        CONTACT_ID,
                        FIRST_NAME,
                        LAST_NAME,
                        "86055512345",
                        ADDRESS));
    }

    @Test
    void testConstructor_withNondigitPhone_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        CONTACT_ID,
                        FIRST_NAME,
                        LAST_NAME,
                        "860555ABCD",
                        ADDRESS));
    }

    @Test
    void testConstructor_withNullAddress_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        CONTACT_ID,
                        FIRST_NAME,
                        LAST_NAME,
                        PHONE,
                        null));
    }

    @Test
    void testConstructor_withAddressLongerThanThirtyCharacters_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        CONTACT_ID,
                        FIRST_NAME,
                        LAST_NAME,
                        PHONE,
                        "1234567890123456789012345678901"));
    }

    @Test
    void testSetters_withValidValues_updateFields() {
        Contact contact = new Contact(
                CONTACT_ID,
                FIRST_NAME,
                LAST_NAME,
                PHONE,
                ADDRESS);

        contact.setFirstName("John");
        contact.setLastName("Smith");
        contact.setPhone("2035559876");
        contact.setAddress("456 Oak Avenue");

        assertAll(
                () -> assertEquals("John", contact.getFirstName()),
                () -> assertEquals("Smith", contact.getLastName()),
                () -> assertEquals("2035559876", contact.getPhone()),
                () -> assertEquals("456 Oak Avenue", contact.getAddress()));
    }
}