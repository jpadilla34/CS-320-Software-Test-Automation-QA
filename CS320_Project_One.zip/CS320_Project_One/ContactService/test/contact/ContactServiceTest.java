package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ContactServiceTest {

    private static final String CONTACT_ID = "1001";
    private static final String FIRST_NAME = "Jeremy";
    private static final String LAST_NAME = "Padilla";
    private static final String PHONE = "8605551234";
    private static final String ADDRESS = "123 Main Street";

    private ContactService service;
    private Contact contact;

    @BeforeEach
    void setUp() {
        service = new ContactService();

        contact = new Contact(
                CONTACT_ID,
                FIRST_NAME,
                LAST_NAME,
                PHONE,
                ADDRESS);
    }

    @Test
    void testAddContact_withUniqueId_contactIsStored() {
        service.addContact(contact);

        assertEquals(
                contact,
                service.getContact(CONTACT_ID));
    }

    @Test
    void testAddContact_withDuplicateId_throwsException() {
        service.addContact(contact);

        Contact duplicate = new Contact(
                CONTACT_ID,
                "Maria",
                "Lopez",
                "2035556789",
                "456 Oak Avenue");

        assertThrows(
                IllegalArgumentException.class,
                () -> service.addContact(duplicate));
    }

    @Test
    void testDeleteContact_withExistingId_contactIsRemoved() {
        service.addContact(contact);

        service.deleteContact(CONTACT_ID);

        assertNull(service.getContact(CONTACT_ID));
    }

    @Test
    void testDeleteContact_withMissingId_throwsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> service.deleteContact("9999"));
    }

    @Test
    void testUpdateContact_withValidContact_contactIsUpdated() {
        service.addContact(contact);

        Contact updatedContact = new Contact(
                CONTACT_ID,
                "John",
                "Smith",
                "2035559876",
                "456 Oak Avenue");

        service.updateContact(updatedContact);

        assertEquals(
                updatedContact,
                service.getContact(CONTACT_ID));
    }

    @Test
    void testUpdateContact_withMissingId_throwsException() {
        Contact missingContact = new Contact(
                "9999",
                "John",
                "Smith",
                "2035559876",
                "456 Oak Avenue");

        assertThrows(
                IllegalArgumentException.class,
                () -> service.updateContact(missingContact));
    }

    @Test
    void testGetContact_withMissingId_returnsNull() {
        assertNull(service.getContact("9999"));
    }

    @Test
    void testGetContact_withExistingId_returnsEqualNewInstance() {
        service.addContact(contact);

        Contact retrievedContact =
                service.getContact(CONTACT_ID);

        assertAll(
                () -> assertEquals(contact, retrievedContact),
                () -> assertNotSame(contact, retrievedContact));
    }
}